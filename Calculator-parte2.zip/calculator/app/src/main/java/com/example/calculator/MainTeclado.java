package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainTeclado extends AppCompatActivity {
    EditText txtvalor;
    Button btnHistory;
    Button btnClear;
    Button btnZero;
    Button btnPonto;
    Button btnIgual;
    Button btnMultiplicar;
    Button btnDividir;
    Button btnTres;
    Button btnDois;
    Button btnUm;
    Button btnMenos;
    Button btnSeis;
    Button btnCinco;
    Button btnQuatro;
    Button btnMais;
    Button btnNove;
    Button btnOito;
    Button btnSete;

    float valorA, valorB;

    boolean crunchifyAddition, msubtract, crunchifymultiplication, crunchifyDivision;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teclado_main);

        txtvalor = findViewById(R.id.txtValor);
        txtvalor.setText("256");
        btnHistory = findViewById(R.id.btnHistory);
        btnClear = findViewById(R.id.btnClear);
        btnZero = findViewById(R.id.btnZero);
        btnPonto = findViewById(R.id.btnPonto);
        btnIgual = findViewById(R.id.btnIgual);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        btnTres = findViewById(R.id.btnTres);
        btnDois = findViewById(R.id.btnDois);
        btnUm = findViewById(R.id.btnUm);
        btnMenos = findViewById(R.id.btnMenos);
        btnSeis = findViewById(R.id.btnSeis);
        btnCinco = findViewById(R.id.btnCinco);
        btnQuatro = findViewById(R.id.btnQuatro);
        btnMais = findViewById(R.id.btnMais);
        btnNove = findViewById(R.id.btnNove);
        btnOito = findViewById(R.id.btnOito);
        btnSete = findViewById(R.id.btnSete);

        btnUm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "1");
            }
        });
        btnDois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "2");
            }
        });
        btnTres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "3");
            }
        });
        btnQuatro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "4");
            }
        });
        btnCinco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "5");
            }
        });
        btnSeis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "6");
            }
        });
        btnSete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "7");
            }
        });
        btnOito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "8");
            }
        });
        btnNove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "9");
            }
        });
        btnZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + "0");
            }
        });
        btnMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtvalor == null) {
                    txtvalor.setText("");
                } else {
                    valorA = Float.parseFloat(txtvalor.getText() + "");
                    crunchifyAddition = true;
                    txtvalor.setText(null);
                }
            }
        });
        btnMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorA = Float.parseFloat(txtvalor.getText() + "");
                msubtract = true;
                txtvalor.setText(null);
            }
        });
        btnMultiplicar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorA = Float.parseFloat(txtvalor.getText() + "");
                crunchifymultiplication = true;
                txtvalor.setText(null);
            }
        });
        btnDividir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorA = Float.parseFloat(txtvalor.getText() + "");
                crunchifyDivision = true;
                txtvalor.setText(null);
            }
        });
        btnIgual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valorB = Float.parseFloat(txtvalor.getText() + "");

                if (crunchifyAddition == true) {
                    txtvalor.setText(valorA + valorB + " ");
                    crunchifyAddition = false;
                }
                if (msubtract == true) {
                    txtvalor.setText(valorA - valorB + " ");
                    msubtract = false;
                }
                if (crunchifymultiplication == true) {
                    txtvalor.setText(valorA * valorB + " ");
                    crunchifymultiplication = false;
                }
                if (crunchifyDivision == true) {
                    txtvalor.setText(valorA / valorB + " ");
                    crunchifyDivision = false;
                }
            }
        });
        btnPonto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtvalor.setText(txtvalor.getText() + ".");
            }
        });
    }


    public void limparTela(View v){
       txtvalor.setText(" ");
    }
    public void  acessarHistory(View v){
        Intent it = new Intent(getBaseContext(), HistoryActivity.class);
        it.putExtra("valor", txtvalor.getText().toString());
        startActivity(it);
    }
}