package com.example.calculator;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ResultadoAdapter extends BaseAdapter {
    LayoutInflater inflater;
    List<Resultado> resultados;

    public  ResultadoAdapter(List<Resultado> resultados, Context ctx){
        this.resultados = resultados;
        inflater = LayoutInflater.from(ctx);
    }
    @Override
    public int getCount(){return resultados.size(); }

    @Override
    public Object getItem(int position){ return resultados.get(position); }

    @Override
    public  long getItemId(int position){return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View v = inflater.inflate(R.layout.resultado_item, null);
        TextView txtValorAItem = v.findViewById(R.id.txtValorAItem);
        TextView txtValorBItem = v.findViewById(R.id.txtValorBItem);
        TextView TxtvalorItem = v.findViewById(R.id.TxtvalorItem);
        Resultado r = resultados.get(position);
        txtValorAItem.setText((int) r.getvalorA());
        txtValorBItem.setText((int) r.getValorB());
        TxtvalorItem.setText((int) r.getTxtvalor());
        return v;
    }
}
