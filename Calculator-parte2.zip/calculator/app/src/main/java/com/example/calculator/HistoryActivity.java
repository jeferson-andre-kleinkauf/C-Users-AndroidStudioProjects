package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class HistoryActivity extends AppCompatActivity {
    Button btnVoltar;
    ListView listResultados;
    List<Resultado> resultados = new ArrayList<>();
    ResultadoAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        btnVoltar = findViewById(R.id.btnVoltar);
        listResultados = findViewById(R.id.listResultados);
        adapter = new ResultadoAdapter(resultados, getBaseContext());
        listResultados.setAdapter(adapter);
    }
    public void  acessarMainTeclado(View v){
        Intent it = new Intent(getBaseContext(), MainTeclado.class);
        startActivity(it);
    }
}