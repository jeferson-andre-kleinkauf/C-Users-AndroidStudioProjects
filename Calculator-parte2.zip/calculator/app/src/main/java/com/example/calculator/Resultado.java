package com.example.calculator;

import androidx.annotation.NonNull;

public class Resultado {
    private float valorA;
    private float valorB;
    private float txtvalor;
    private String Txtvalor;


    public void setValorA(float valorA){this.valorA = valorA; }
    public void setValorB(float valorB){this.valorB = valorB; }
    public void setTxtvalor(float Txtvalor){this.txtvalor = Txtvalor; }

 @NonNull
 @Override
 public String toString(){ return " " + valorA + " " + valorB + " " + Txtvalor;}

 public float getvalorA() {return valorA;}

 public float getValorB() {return valorB;}

 public float getTxtvalor() {return txtvalor ;}

}
