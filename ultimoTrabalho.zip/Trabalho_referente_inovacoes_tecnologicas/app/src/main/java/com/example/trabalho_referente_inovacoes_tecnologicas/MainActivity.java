package com.example.trabalho_referente_inovacoes_tecnologicas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;

import javax.annotation.Nonnull;

public class MainActivity extends AppCompatActivity {
    private EditText EditEmail, EditSenha;
    private Button cadastrar, navegar, cadastrarestabelecimento;
    private ProgressBar barradecarregamento;
    String[] informacao = {"informe seus dados corretamente", "login autorizado"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        IniciarDados();

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent it = new Intent(MainActivity.this, Add_Cliente.class);
                startActivity(it);
            }
        });
        navegar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                /*String email = EditEmail.getText().toString();
                String senha = EditSenha.getText().toString();
                if (email.isEmpty() || senha.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(v, informacao[0], Snackbar.LENGTH_INDEFINITE);
                    snackbar.setBackgroundTint(Color.RED);
                    snackbar.setTextColor(Color.BLUE);
                    snackbar.show();
                } else {
                    aceitarusuario(v);
                }*/
                Intent it = new Intent(MainActivity.this, ListEstabelecimento.class);
                startActivity(it);
            }
        });
        cadastrarestabelecimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, Add_Estabelecimento.class);
                startActivity(it);
            }
        });
    }

    /*private void aceitarusuario( View view) {
        String email = EditEmail.getText().toString();
        String senha = EditSenha.getText().toString();
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@Nonnull Task<AuthResult> task) {

                if (task.isSuccessful()){
                    barradecarregamento.setVisibility(View.VISIBLE);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            Lanches();
                        }
                    },3000);
                } else {
                    String erro;
                    try {
                        throw task.getException();
                    } catch (Exception e){
                        erro ="falha ao se logar";
                    }
                    Snackbar snackbar = Snackbar.make(view, informacao[0], Snackbar.LENGTH_INDEFINITE);
                    snackbar.setBackgroundTint(Color.RED);
                    snackbar.setTextColor(Color.BLUE);
                    snackbar.show();
                }
            }
        });
    }*/

    /*@Override
    /*
    protected void onStart() {
        super.onStart();
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();
        if (usuarioAtual != null){
            TelaPrincial();
        }
    }
    */
   /* private void TelaPrincial(){
        Intent intent = new Intent(MainActivity.this, Lanches.class);
        startActivity(intent);
        finish();
    }*/
    private void IniciarDados(){
        EditEmail = findViewById(R.id.editEmail);
        EditSenha = findViewById(R.id.editSenha);
        navegar = findViewById(R.id.navegar);
        cadastrar = findViewById(R.id.cadastrar);
        cadastrarestabelecimento = findViewById(R.id.cadastrarestabelecimento);
    }












}