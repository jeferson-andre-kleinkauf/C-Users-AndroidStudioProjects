package com.example.trabalho_referente_inovacoes_tecnologicas;

public class Estabelecimento {
}
