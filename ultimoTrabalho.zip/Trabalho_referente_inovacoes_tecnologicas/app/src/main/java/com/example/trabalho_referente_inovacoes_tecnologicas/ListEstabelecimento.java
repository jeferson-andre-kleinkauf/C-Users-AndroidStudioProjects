package com.example.trabalho_referente_inovacoes_tecnologicas;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ListEstabelecimento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_estabelecimento);
    }
}