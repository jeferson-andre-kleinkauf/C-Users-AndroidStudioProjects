package com.example.trabalho_referente_inovacoes_tecnologicas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Add_Estabelecimento extends AppCompatActivity {

    private Button novoestabelecimento;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_estabelecimento);
        novoestabelecimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent It = new Intent(Add_Estabelecimento.this, ListEstabelecimento.class);
                startActivity(It);
            }
        });
    }
    private void iniciarbotao(){
        novoestabelecimento = findViewById(R.id.novoestabelecimento);
    }

}