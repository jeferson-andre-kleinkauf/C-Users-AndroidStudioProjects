package com.example.trabalho_referente_inovacoes_tecnologicas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
/*import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;*/
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;


public class Add_Cliente extends AppCompatActivity {

    private EditText EditNome, editEmail, editSenha;
    private Button habilitar;
    /*String[] informacao = {"informe seus dados corretamente", "cliente cadastrado"};
    String userID;*/
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_cliente);

        getSupportActionBar().hide();
        comecardados();
        habilitar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*String nome = EditNome.getText().toString();
                String Email = editEmail.getText().toString();
                String senha = editSenha.getText().toString();

                if (nome.isEmpty() || Email.isEmpty() || senha.isEmpty()){
                    Snackbar snackbar = Snackbar.make(v,informacao[0],Snackbar.LENGTH_INDEFINITE);
                    snackbar.setBackgroundTint(Color.RED);
                    snackbar.setTextColor(Color.BLUE);
                    snackbar.show();
                } else {
                    habilitarlogin(v);
                }*/
                Intent it = new Intent(Add_Cliente.this, MainActivity.class);
                startActivity(it);
            }
        });
    }
    /*private void habilitarlogin( View v){

        String Email = editEmail.getText().toString();
        String senha = editSenha.getText().toString();

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(Email, senha).addCompleteListener(new OnCompleteListener<AuthResult>(){
            @Override
            public void onComplete(@Nonnull Task<AuthResult> task){
                if (task.isSuccessful()){

                    salvarInformacoesuser();
                    Snackbar snackbar = Snackbar.make(v,informacao[1],Snackbar.LENGTH_INDEFINITE);
                    snackbar.setBackgroundTint(Color.RED);
                    snackbar.setTextColor(Color.BLUE);
                    snackbar.show();
                } else {
                    String erro;
                    try {
                        throw task.getException();
                    }catch (FirebaseAuthWeakPasswordException e) {
                        erro = "Digite uma senha com no minimo 8 caracteres";
                    } catch(FirebaseAuthCollissionException e){
                        erro ="Email cadastrado";
                    }catch (FirebaseAuthCredentialsException e){
                      erro = "Email invalido";
                    }
                    catch (Exception e){
                        erro = "Erro ao cadastrar usuario";
                    }
                    Snackbar snackbar = Snackbar.make(v,erro,Snackbar.LENGTH_INDEFINITE);
                    snackbar.setBackgroundTint(Color.RED);
                    snackbar.setTextColor(Color.BLUE);
                    snackbar.show();
                }
            }
        });
    }*/
    /*private void  salvarInformacoesuser(){
        String nome = EditNome.getText().toString();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> user = new HashMap<>();
        user.put("nome", nome);
        userID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("user").document(userID);
        documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void avoid) {
                Log.d("db","Sucesso ao salvar as informações");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("db_error", "Erro ao salvar os dados" + e.toString());
                    }
                });
    }*/
    private void comecardados(){
        EditNome = findViewById(R.id.EditNome);
        editEmail = findViewById(R.id.editEmail);
        editSenha = findViewById(R.id.editSenha);
        habilitar = findViewById(R.id.habilitar);
    }
}