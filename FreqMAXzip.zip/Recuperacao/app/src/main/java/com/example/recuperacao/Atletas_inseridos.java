package com.example.recuperacao;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.List;

public class Atletas_inseridos extends AppCompatActivity {

    EditText txtNome;
    EditText txtIdade;
    Button btnAdicionareCalcular;
    ListView listAtletas;
    List<Atleta> atletas = new ArrayList<>();
    AtletaAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atletas_inseridos);

        txtNome = findViewById(R.id.txtNome);
        txtIdade = findViewById(R.id.txtIdade);
        btnAdicionareCalcular = findViewById(R.id.btnAdicionareCalcular);
        btnAdicionareCalcular.setOnClickListener(btClickListener);
        listAtletas = findViewById(R.id.listAtletas);
        adapter = new AtletaAdapter(atletas, getBaseContext());
        listAtletas.setAdapter(adapter);
    }

     View.OnClickListener btClickListener = this::acessartelaAtletasinseridos;
    public void  acessartelaAtletasinseridos(View v){
        Atleta a = new Atleta();
        a.setNome(txtNome.getText().toString());
        a.setIdade(Integer.parseInt(txtIdade.getText().toString()));
        atletas.add(a);
        adapter.notifyDataSetChanged();
    }
}
