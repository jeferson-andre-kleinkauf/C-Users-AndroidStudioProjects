package com.example.recuperacao;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class AtletaAdapter extends BaseAdapter {
    LayoutInflater inflater;
    List<Atleta> atletas;

    public AtletaAdapter(List<Atleta> atletas, Context ctx){
        this.atletas = atletas;
        inflater = LayoutInflater.from(ctx);
    }
    @Override
    public int getCount() {
        return atletas.size();
    }

    @Override
    public Object getItem(int position) {
        return atletas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = inflater.inflate(R.layout.atleta_item, null);
        TextView txtNomeItem = v.findViewById(R.id.txtNomeItem);
        TextView txtfcmItem = v.findViewById(R.id.txtfcmItem);
        Atleta a = atletas.get(position);
        txtNomeItem.setText(a.getNome());
        txtfcmItem.setText(String.valueOf(200 - a.getIdade()));
        return v;
    }
}

