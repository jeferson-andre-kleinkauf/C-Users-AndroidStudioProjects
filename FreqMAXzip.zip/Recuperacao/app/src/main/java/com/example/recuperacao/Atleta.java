package com.example.recuperacao;

import androidx.annotation.NonNull;

public class Atleta {
    private String nome;
    private int idade;



    public void setNome(String nome){
        this.nome = nome;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    @NonNull
    @Override
    public String toString(){
        return "Nome" + nome + " Idade " + idade;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
}
