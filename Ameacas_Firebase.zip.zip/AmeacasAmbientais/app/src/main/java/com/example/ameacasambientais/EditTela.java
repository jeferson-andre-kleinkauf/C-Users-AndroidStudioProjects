package com.example.ameacasambientais;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditTela extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference();
    DatabaseReference ameacasambientais = root.child(Tela_Inicial.AMEACASAMBIENTAIS_KEY);
    EditText edtEndereco, edtData, edtDescricao;
    AmeacaAmbiental current;
    String key;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_edicao);

        edtEndereco = findViewById(R.id.edtEndereco);
        edtData = findViewById(R.id.edtData);
        edtDescricao = findViewById(R.id.edtDescricao);
        key = getIntent().getStringExtra("KEY");
        current = (AmeacaAmbiental) getIntent().getSerializableExtra("STD");
        edtEndereco.setText(current.getEndereco());
        edtData.setText(current.getData());
        edtDescricao.setText(current.getDescricao());
    }
    public void updateAmeacaAmbiental(View v){
        current.setEndereco(edtEndereco.getText().toString());
        current.setData(edtData.getText().toString());
        current.setDescricao(edtDescricao.getText().toString());
        ameacasambientais.child(key).setValue(current);
        finish();
    }
}