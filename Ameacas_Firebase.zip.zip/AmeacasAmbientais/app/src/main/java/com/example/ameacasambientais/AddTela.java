package com.example.ameacasambientais;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;


public class AddTela extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference();
    DatabaseReference ameacasambientais = root.child(Tela_Inicial.AMEACASAMBIENTAIS_KEY);
    EditText edtEndereco, edtData, edtDescricao;
    public static final int CAMERA_CALL = 1022;
    Bitmap bmp;
    ImageView image;
    boolean hasImage = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_adicao);

        edtEndereco = findViewById(R.id.edtEndereco);
        edtData = findViewById(R.id.edtData);
        edtDescricao = findViewById(R.id.edtDescricao);
        image = findViewById(R.id.image);
    }
    public String loadImage() {
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, byteOut);
        return Base64.encodeToString(byteOut.toByteArray(), Base64.DEFAULT);
    }
    public void addAmeacaAmbiental(View v){
        AmeacaAmbiental aa = new AmeacaAmbiental();
        aa.setEndereco(edtEndereco.getText().toString());
        aa.setData(edtData.getText().toString());
        aa.setDescricao(edtDescricao.getText().toString());
    if(hasImage){
        String bmpEncoded = loadImage();
        hasImage = false;
        aa.setImage(bmpEncoded);
        }
    String key = ameacasambientais.push().getKey();
    ameacasambientais.child(key).setValue(aa);
    finish();
    }

    public void takePicture(View v) {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, CAMERA_CALL);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_CALL && resultCode == RESULT_OK){
            bmp = (Bitmap) data.getExtras().get("data");
            image.setImageBitmap(bmp);
            hasImage = true;
        }
    }
}