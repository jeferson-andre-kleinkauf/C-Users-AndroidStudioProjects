package com.example.ameacasambientais;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Tela_Inicial extends AppCompatActivity {
    public static final String AMEACASAMBIENTAIS_KEY = "ameacasambientais";
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference();
    DatabaseReference ameacasambientais = root.child(AMEACASAMBIENTAIS_KEY);
    FirebaseListAdapter<AmeacaAmbiental>listAdapter;
    ListView listAmeacaAmbiental;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_inicial);


        listAmeacaAmbiental = findViewById(R.id.listTelaInicial);
        listAdapter = new FirebaseListAdapter<AmeacaAmbiental>(this, AmeacaAmbiental.class, R.layout.ameacaambiental_list_item, ameacasambientais) {
            @Override
            protected void populateView(View v, AmeacaAmbiental model, int position) {
                TextView txtAmeacaAmbientalDescricao = v.findViewById(R.id.txtAmeacaAmbientalDescricao);
                ImageView imageItem = v.findViewById(R.id.imageItem);
                txtAmeacaAmbientalDescricao.setText(model.getDescricao());
                if (model.getImage() != null){
                    byte imageData[] =Base64.decode(model.getImage(), Base64.DEFAULT);
                    Bitmap img = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
                    imageItem.setImageBitmap(img);
                }
            }
        };
        listAmeacaAmbiental.setAdapter(listAdapter);
        listAmeacaAmbiental.setOnItemLongClickListener((parent, view, position, id) -> {
            DatabaseReference item = listAdapter.getRef(position);
            item.removeValue();
            return false;
            });
            listAmeacaAmbiental.setOnItemClickListener((parent, view, position, id) -> {
                DatabaseReference item = listAdapter.getRef(position);
                changeToUpdate(item.getKey(), listAdapter.getItem(position));
            });
    }
            public void changeToAdd(View v){
            Intent it = new Intent(getBaseContext(), AddTela.class);
            startActivity(it);
        }
        public void changeToUpdate(String key, AmeacaAmbiental aa){
                Intent it = new Intent(getBaseContext(), EditTela.class);
                it.putExtra("KEY", key);
                it.putExtra("STD", aa);
                startActivity(it);
        }


}