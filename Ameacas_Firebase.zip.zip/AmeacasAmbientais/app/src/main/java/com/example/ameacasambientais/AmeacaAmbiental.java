package com.example.ameacasambientais;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class AmeacaAmbiental implements Serializable {
    private String endereco;
    private String data;
    private String descricao;
    private String image;

    public AmeacaAmbiental (){

    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    @NonNull
    @Override
    public String toString(){
        return endereco + " " + data + " " + descricao ;
    }
}

